﻿namespace Mikroservice_Fitness;

public class Class1
{
}