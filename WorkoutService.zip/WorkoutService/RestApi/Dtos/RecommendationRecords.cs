﻿using System.ComponentModel.DataAnnotations;

namespace RestApi.Dtos;

public class CreateRecommendationDto();
public class ReadRecommendationDto();
public class UpdateRecommendationDto();
