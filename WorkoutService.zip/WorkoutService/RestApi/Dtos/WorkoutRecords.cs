﻿using System.ComponentModel.DataAnnotations;

namespace RestApi.Dtos;

public class CreateWorkoutDto();
public class ReadWorkoutDto();
public class UpdateWorkoutDto();